import { useState } from "react";
import BookList from "../components/BookList";
import AddBookComponent from "../components/AddBookComponent";
import DeleteBookComponent from "../components/DeleteBookComponent";
import UpdateBookComponent from "../components/UpdateBookComponent";
import "./Admin.css";

function Admin() {
  const [updateKey, setUpdateKey] = useState(0);

  const refreshBooks = () => {
    setUpdateKey((prevKey) => prevKey + 1); // Increment the key to trigger re-render
  };

  return (
    <div className="container my-4">
      <div className="card shadow-sm">
        <div className="card-header bg-primary text-white">
          <h4 className="mb-0">Admin Page</h4>
        </div>

        <section className="card-body">
          <div className="row g-3">
            <AddBookComponent onBookAdded={refreshBooks} />
            <DeleteBookComponent onBookDelete={refreshBooks} />
            <UpdateBookComponent onBookUpdate={refreshBooks} />
            <div>
              <BookList refreshKey={updateKey} />
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}

export default Admin;
